<x-layouts>
    <x-slot:heading>
        About Page
    </x-slot:heading>
    <h1>This is About Page!</h1>
</x-layouts>