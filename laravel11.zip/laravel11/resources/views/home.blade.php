<x-layouts>
    <x-slot:heading>
        Home Page
    </x-slot:heading>
    <h1>This is Home Page!</h1>
</x-layouts>