<x-layouts>
    <x-slot:heading>
        Contact Page
    </x-slot:heading>
    <h1>This is Contact Page!</h1>
</x-layouts>