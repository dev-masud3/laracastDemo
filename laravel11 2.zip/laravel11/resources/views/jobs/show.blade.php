<x-layouts>
    <x-slot:heading>
        Job Page
    </x-slot:heading>
    <h1>{{ $job['title'] }}</h1>
    <p>{{ $job['salary'] }}</p>
</x-layouts>